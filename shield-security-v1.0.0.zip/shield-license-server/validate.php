<?php
/**
 * Shield Security — License Validation Endpoint
 * Host this on any PHP server (e.g. your own WP site, cPanel, shared hosting)
 *
 * Deploy to: https://yourdomain.com/shield-license/validate.php
 * Then update SHIELD_LICENSE_VALIDATE_URL in shield-security/includes/license.php
 *
 * This is a MINIMAL reference implementation.
 * For production use, replace the $licenses array with a real database lookup
 * (e.g. connect to WooCommerce orders, Lemon Squeezy webhooks, or any DB).
 */

header( 'Content-Type: application/json' );
header( 'Access-Control-Allow-Origin: *' );

// ── Very simple: only accept POST ────────────────────────────────────
if ( $_SERVER['REQUEST_METHOD'] !== 'POST' ) {
    http_response_code( 405 );
    echo json_encode( array( 'valid' => false, 'message' => 'Method not allowed' ) );
    exit;
}

$key    = trim( $_POST['license_key'] ?? '' );
$domain = trim( $_POST['domain']      ?? '' );
$action = trim( $_POST['action']      ?? 'check' );

if ( empty( $key ) || empty( $domain ) ) {
    echo json_encode( array( 'valid' => false, 'message' => 'Missing parameters' ) );
    exit;
}

// ── License database ──────────────────────────────────────────────────
// REPLACE THIS with a real DB query in production.
// Format: 'LICENSE-KEY' => array( 'max_sites' => N, 'expires' => 'YYYY-MM-DD' or null )
$licenses = array(
    'SHIELD-DEMO-0000-0000' => array( 'max_sites' => 1,  'expires' => null ),
    'SHIELD-AGCY-XXXX-XXXX' => array( 'max_sites' => 10, 'expires' => null ),
    // Add real keys here, or replace with DB lookup
);

// ── Activation store ──────────────────────────────────────────────────
// Stores activated domains in a JSON file alongside this script.
// Replace with a real DB table in production.
$store_file = __DIR__ . '/activations.json';
$store = file_exists( $store_file )
    ? json_decode( file_get_contents( $store_file ), true )
    : array();
if ( ! is_array( $store ) ) $store = array();

// ── Validate key ──────────────────────────────────────────────────────
if ( ! isset( $licenses[ $key ] ) ) {
    echo json_encode( array( 'valid' => false, 'message' => 'Invalid license key' ) );
    exit;
}

$lic = $licenses[ $key ];

// Check expiry
if ( ! empty( $lic['expires'] ) && strtotime( $lic['expires'] ) < time() ) {
    echo json_encode( array( 'valid' => false, 'message' => 'License expired on ' . $lic['expires'] ) );
    exit;
}

// ── Handle actions ────────────────────────────────────────────────────
if ( $action === 'activate' ) {
    $sites = isset( $store[ $key ] ) ? $store[ $key ] : array();

    // Already activated on this domain? Allow re-activation.
    if ( ! in_array( $domain, $sites, true ) ) {
        if ( count( $sites ) >= $lic['max_sites'] ) {
            echo json_encode( array(
                'valid'   => false,
                'message' => 'License already used on maximum number of sites (' . $lic['max_sites'] . '). Deactivate on another site first.',
            ) );
            exit;
        }
        $sites[] = $domain;
        $store[ $key ] = $sites;
        file_put_contents( $store_file, json_encode( $store, JSON_PRETTY_PRINT ) );
    }

    echo json_encode( array( 'valid' => true, 'message' => 'Activated', 'sites_used' => count( $sites ), 'max_sites' => $lic['max_sites'] ) );
    exit;
}

if ( $action === 'deactivate' ) {
    if ( isset( $store[ $key ] ) ) {
        $store[ $key ] = array_values( array_filter( $store[ $key ], function( $d ) use ( $domain ) {
            return $d !== $domain;
        } ) );
        file_put_contents( $store_file, json_encode( $store, JSON_PRETTY_PRINT ) );
    }
    echo json_encode( array( 'valid' => true, 'message' => 'Deactivated' ) );
    exit;
}

// action = 'check'
$sites = isset( $store[ $key ] ) ? $store[ $key ] : array();
$is_activated = in_array( $domain, $sites, true );

if ( ! $is_activated ) {
    echo json_encode( array( 'valid' => false, 'message' => 'Not activated on this domain' ) );
    exit;
}

echo json_encode( array( 'valid' => true, 'message' => 'Valid', 'sites_used' => count( $sites ), 'max_sites' => $lic['max_sites'] ) );
